// Arithmetic Operations
function add(a, b) { return a + b; }
function subtract(a, b) { return a - b; }
function multiply(a, b) { return a * b; }
function divide(a, b) { return b === 0 ? "Error: Division by zero" : a / b; }

// Sum of numbers from 1 to n
function summation(n) {
    if (n < 1) return "Input must be ≥ 1";
    return (n * (n + 1)) / 2; 
}